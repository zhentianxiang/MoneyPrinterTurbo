import os
import torch
import uuid
import uvicorn
import random
import numpy as np
import soundfile as sf
from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from qwen_tts import Qwen3TTSModel
from contextlib import asynccontextmanager

# --- 配置路径 ---
import os
MODEL_BASE = os.path.join(".", "Qwen")
SAMPLES_DIR = os.path.join(".", "templates", "samples")
MODELS = {
    "custom": os.path.join(MODEL_BASE, "Qwen3-TTS-12Hz-1.7B-CustomVoice"),
    "design": os.path.join(MODEL_BASE, "Qwen3-TTS-12Hz-1.7B-VoiceDesign"),
    "base": os.path.join(MODEL_BASE, "Qwen3-TTS-12Hz-1.7B-Base")
}
OUTPUT_DIR = "outputs"

# 自动检测最佳设备
def detect_best_device():
    if not torch.cuda.is_available():
        return "cpu"
    
    # 优先尝试 cuda:1（4090）
    try:
        device = torch.device("cuda:1")
        # 测试设备是否可用
        x = torch.tensor([1.0], device=device)
        return "cuda:1"
    except Exception as e:
        print(f"⚠️  cuda:1 不可用: {e}")
    
    # 尝试 cuda:0
    try:
        device = torch.device("cuda:0")
        # 测试设备是否可用
        x = torch.tensor([1.0], device=device)
        return "cuda:0"
    except Exception as e:
        print(f"⚠️  cuda:0 不可用: {e}")
    
    # 尝试默认 cuda
    try:
        device = torch.device("cuda")
        # 测试设备是否可用
        x = torch.tensor([1.0], device=device)
        return "cuda"
    except Exception as e:
        print(f"⚠️  cuda 不可用: {e}")
    
    return "cpu"

DEVICE = detect_best_device() 

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs("templates", exist_ok=True)

loaded_models = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"🚀 正在加载核心模型...")
    print(f"🔍 检测到的设备: {DEVICE}")
    
    try:
        for key, path in MODELS.items():
            if os.path.exists(path):
                print(f"📦 加载 {key} 模型...")
                try:
                    # 优先尝试使用检测到的设备加载模型
                    if "cuda" in DEVICE:
                        print(f"🔄 尝试在 {DEVICE} 上加载模型...")
                        loaded_models[key] = Qwen3TTSModel.from_pretrained(
                            path, device_map=DEVICE, dtype=torch.bfloat16, attn_implementation="sdpa"
                        )
                        print(f"✅ {key} 模型在 {DEVICE} 上加载成功！")
                    else:
                        # 在 CPU 上加载模型
                        print("🔄 尝试在 CPU 上加载模型...")
                        loaded_models[key] = Qwen3TTSModel.from_pretrained(
                            path, device_map="cpu", dtype=torch.float32, attn_implementation="eager"
                        )
                        print(f"✅ {key} 模型在 CPU 上加载成功！")
                except Exception as e:
                    print(f"❌ {key} 模型加载失败: {e}")
                    # 如果 GPU 加载失败，尝试在 CPU 上加载
                    if "cuda" in DEVICE:
                        print(f"🔄 尝试在 CPU 上加载 {key} 模型...")
                        try:
                            loaded_models[key] = Qwen3TTSModel.from_pretrained(
                                path, device_map="cpu", dtype=torch.float32, attn_implementation="eager"
                            )
                            print(f"✅ {key} 模型在 CPU 上加载成功！")
                        except Exception as cpu_e:
                            print(f"❌ {key} 模型在 CPU 上也加载失败: {cpu_e}")
        if loaded_models:
            print("✅ 部分模型已就绪！")
        else:
            print("⚠️  没有模型加载成功，请检查模型路径和环境")
    except Exception as e:
        print(f"❌ 加载过程出错: {e}")
    yield
    loaded_models.clear()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

app = FastAPI(lifespan=lifespan)
app.mount("/outputs", StaticFiles(directory=OUTPUT_DIR), name="outputs")
app.mount("/samples", StaticFiles(directory=SAMPLES_DIR), name="samples")
templates = Jinja2Templates(directory="templates")

# --- 核心路由 ---

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    # 只加载 design 模型的 speakers
    speakers = loaded_models['design'].get_supported_speakers() if 'design' in loaded_models else []
    return templates.TemplateResponse("index.html", {"request": request, "speakers": speakers})

@app.post("/generate/{mode}")
async def generate(
    mode: str,
    text: str = Form(...),
    speaker: str = Form(None),
    instruct: str = Form(None),
    ref_text: str = Form(None),
    seed: int = Form(-1),
    ref_file: UploadFile = File(None)
):
    if mode not in loaded_models:
        return JSONResponse({"error": f"模型 {mode} 未加载"}, status_code=500)
    
    model = loaded_models[mode]
    actual_seed = -1  # 默认不返回有效种子

    try:
        # 仅在官方角色 (custom) 模式下启用种子锁定
        if mode == "custom":
            actual_seed = seed if seed != -1 else random.randint(1, 1000000)
            
            # 设置随机环境
            random.seed(actual_seed)
            np.random.seed(actual_seed)
            torch.manual_seed(actual_seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed(actual_seed)
            
            # 开启 CUDA 确定性模式
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
            
            print(f"🎲 [Locked] Mode: custom | Seed: {actual_seed}")
        else:
            # design 和 base 模式使用默认随机状态
            torch.backends.cudnn.deterministic = False
            torch.backends.cudnn.benchmark = True

        # 根据是否有 GPU 选择不同的推理模式
        if torch.cuda.is_available():
            with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                if mode == "custom":
                    wavs, sr = model.generate_custom_voice(text=text, speaker=speaker, instruct=instruct)
                
                elif mode == "design":
                    wavs, sr = model.generate_voice_design(text=text, instruct=instruct)
                
                elif mode == "base":
                    ref_path = None
                    if ref_file and ref_file.filename:
                        ref_path = f"temp_{uuid.uuid4()}.wav"
                        content = await ref_file.read()
                        with open(ref_path, "wb") as f: f.write(content)
                    elif instruct and instruct.endswith(('.mp3', '.wav', '.flac')):
                        potential_path = os.path.join(SAMPLES_DIR, instruct)
                        if os.path.exists(potential_path):
                            ref_path = potential_path

                    if not ref_path:
                        return JSONResponse({"error": "请提供参考音频"}, status_code=400)

                    wavs, sr = model.generate_voice_clone(text=text, ref_audio=ref_path, ref_text=ref_text if ref_text else "")
                    
                    if "temp_" in ref_path and os.path.exists(ref_path):
                        os.remove(ref_path)
        else:
            # CPU 模式
            with torch.inference_mode():
                if mode == "custom":
                    wavs, sr = model.generate_custom_voice(text=text, speaker=speaker, instruct=instruct)
                
                elif mode == "design":
                    wavs, sr = model.generate_voice_design(text=text, instruct=instruct)
                
                elif mode == "base":
                    ref_path = None
                    if ref_file and ref_file.filename:
                        ref_path = f"temp_{uuid.uuid4()}.wav"
                        content = await ref_file.read()
                        with open(ref_path, "wb") as f: f.write(content)
                    elif instruct and instruct.endswith(('.mp3', '.wav', '.flac')):
                        potential_path = os.path.join(SAMPLES_DIR, instruct)
                        if os.path.exists(potential_path):
                            ref_path = potential_path

                    if not ref_path:
                        return JSONResponse({"error": "请提供参考音频"}, status_code=400)

                    wavs, sr = model.generate_voice_clone(text=text, ref_audio=ref_path, ref_text=ref_text if ref_text else "")
                    
                    if "temp_" in ref_path and os.path.exists(ref_path):
                        os.remove(ref_path)

        # 保存结果
        file_name = f"{mode}_{uuid.uuid4()}.wav"
        file_path = os.path.join(OUTPUT_DIR, file_name)
        sf.write(file_path, wavs[0], sr)
        
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        return {"audio_url": f"/outputs/{file_name}", "seed": int(actual_seed)}

    except Exception as e:
        print(f"ERROR: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=500)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7000)
